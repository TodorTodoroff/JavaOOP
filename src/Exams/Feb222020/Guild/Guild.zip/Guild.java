package guild;

import java.util.*;


public class Guild {
    private String name;
    private int capacity;
    private Map<String, Player> players;

    public Guild(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.players = new LinkedHashMap<>();

    }

    public void addPlayer(Player player) {
        if (capacity > players.size()) {
            this.players.put(player.getName(), player);
        }
    }

    public Boolean removePlayer(String name) {
        return this.players.remove(name) != null;
    }

    public void promotePlayer(String name) {
        Player player = this.players.get(name);
        if (player != null) {
            player.setRank("Member");
        }
    }

    public void demotePlayer(String name) {
        this.players.get(name).setRank("Trial");
    }

    public Player[] kickPlayersByClass(String clazz) {

        List<String> names = new ArrayList<>();

        for (var entry : players.entrySet()) {
            Player player = entry.getValue();
            if (player.getClazz().equals(clazz)){
                names.add(entry.getKey());
            }
        }
        Player[] removedPlayers = new Player[names.size()];

        for (int i = 0; i < names.size(); i++) {
            Player player = this.players.remove(names.get(i));
            removedPlayers[i] = player;
        }
        return removedPlayers;
    }

    public int count() {
        return this.players.size();
    }
    public String report(){
        StringBuilder out = new StringBuilder("Players in the guild: " + name + ":").append("\n");
        for (Player value : players.values()) {
            out.append(value).append(System.lineSeparator());
        }
        return out.toString();
    }

}
