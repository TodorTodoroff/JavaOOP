package vehicle;

public interface Vehicle {
    String drive(double kilometers);

    void refuel(double fuelRefueled);

}
