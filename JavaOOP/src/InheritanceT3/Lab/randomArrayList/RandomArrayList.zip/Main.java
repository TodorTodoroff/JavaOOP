//package InheritanceT3.Lab.randomArrayList;

public class Main {
    public static void main(String[] args) {

    }
}
