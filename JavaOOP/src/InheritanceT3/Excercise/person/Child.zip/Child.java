//package InheritanceT3.Excercise.person;

public class Child extends Person {

    public Child(String name, int age) {
        super(name, age);
    }
}
