//package InheritanceT3.Excercise.playersAndMonsters;

public class Knight extends Hero{
    public Knight (String username, int level){
        super(username, level);
    }
}
