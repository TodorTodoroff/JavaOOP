//package InheritanceT3.Excercise.playersAndMonsters;

public class MuseElf extends Elf{
    public MuseElf (String name, int level){
        super(name, level);
    }
}
