//package InheritanceT3.Excercise.playersAndMonsters;

public class SoulMaster extends DarkWizard{
    public SoulMaster (String username, int level){
        super(username, level);
    }
}
