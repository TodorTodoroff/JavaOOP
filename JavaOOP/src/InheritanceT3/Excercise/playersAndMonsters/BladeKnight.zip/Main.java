//package InheritanceT3.Excercise.playersAndMonsters;

public class Main {
    public static void main(String[] args) {

    }
}
