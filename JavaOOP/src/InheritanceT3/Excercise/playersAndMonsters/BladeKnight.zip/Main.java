//package InheritanceT3.Excercise.playersAndMonsters;

public class Main {

}
