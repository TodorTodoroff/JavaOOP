//package InheritanceT3.Excercise.playersAndMonsters;

public class Wizard extends Hero{
    public Wizard (String username, int level){
        super(username, level);
    }
}
