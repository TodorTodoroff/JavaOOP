//package InheritanceT3.Excercise.playersAndMonsters;

public class BladeKnight extends DarkKnight{
    public BladeKnight(String username, int level) {
        super(username, level);
    }
}
