//package InterfacesAndAbstractionT4.Lab.sayHello;

public interface Person {
    String getName();

    String sayHello();
}
