//package InterfacesAndAbstractionT4.Exercises.defineAnInterfacePerson;

public interface Person {

    String getName();

    int getAge();
}
