//package InterfacesAndAbstractionT4.Exercises.birthdayCelebrations;

public interface Birthable {
    String getBirthDate();
}
