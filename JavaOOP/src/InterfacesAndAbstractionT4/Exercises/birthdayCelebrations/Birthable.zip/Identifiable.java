//package InterfacesAndAbstractionT4.Exercises.birthdayCelebrations;

public interface Identifiable {
    String getId();
}
