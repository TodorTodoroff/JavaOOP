//package InterfacesAndAbstractionT4.Exercises.multipleImplementation;

public interface Birthable{
    String getBirthDate();
}
