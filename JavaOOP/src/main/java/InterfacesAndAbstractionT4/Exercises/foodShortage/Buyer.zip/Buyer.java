//package InterfacesAndAbstractionT4.Exercises.foodShortage;

public interface Buyer {

    void buyFood();

    int getFood();
}
