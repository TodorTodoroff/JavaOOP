//package InterfacesAndAbstractionT4.Exercises.foodShortage;

public interface Person {
    String getName();

    int getAge();
}
