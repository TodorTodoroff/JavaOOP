//package InterfacesAndAbstractionT4.Exercises.foodShortage;

public interface Identifiable {
    String getId();
}
