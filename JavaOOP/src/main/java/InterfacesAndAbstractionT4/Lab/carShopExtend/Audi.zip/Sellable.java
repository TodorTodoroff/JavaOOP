//package InterfacesAndAbstractionT4.Lab.carShopExtend;

public interface Sellable {
    Double getPrice();
}