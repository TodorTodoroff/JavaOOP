//package InterfacesAndAbstractionT4.Lab.carShopExtend;

public interface Rentable {
    Integer getMinRentDay();
    Double getPricePerDay();
}
