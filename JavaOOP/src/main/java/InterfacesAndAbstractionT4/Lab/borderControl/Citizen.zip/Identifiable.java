//package InterfacesAndAbstractionT4.Lab.borderControl;

public interface Identifiable {
    String getId();

}
