package WorkingWithAbstractionT1.Exercise.TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW
}
