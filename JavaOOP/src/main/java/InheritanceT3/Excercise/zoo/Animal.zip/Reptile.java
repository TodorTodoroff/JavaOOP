//package InheritanceT3.Excercise.zoo;

public class Reptile extends Animal{
    public Reptile(String name){
        super(name);
    }

}
