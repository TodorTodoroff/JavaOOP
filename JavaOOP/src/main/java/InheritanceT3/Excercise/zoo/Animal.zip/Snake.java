//package InheritanceT3.Excercise.zoo;

public class Snake extends Reptile{
    public Snake(String name){
        super(name);
    }
}
