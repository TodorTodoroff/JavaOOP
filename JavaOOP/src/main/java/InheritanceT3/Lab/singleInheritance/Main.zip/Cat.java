//package InheritanceT3.Lab.singleInheritance;

public class Cat extends Animal{
    public void meow(){
        System.out.println("meowing...");
    }
}
