package WorkingWithAbstractionT1.Exercise.CardSuit;

public enum CardSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES
}
