//package Generics7.Lab.Jar;

public class Main {
    public static void main(String[] args) {


        Jar<Integer> integerJar = new Jar<>();

    }
}

