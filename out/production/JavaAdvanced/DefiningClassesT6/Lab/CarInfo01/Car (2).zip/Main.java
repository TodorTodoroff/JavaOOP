package DefiningClassesT6.Lab.CarInfo01;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Object> carList = new ArrayList<>();
        int n = Integer.parseInt(scanner.nextLine());


        while (n-- > 0) {
            String[] input = scanner.nextLine().split("\\s+");
            if (input.length > 1) {
                Car car = new Car(input[0], input[1], Integer.parseInt(input[2]));
                carList.add(car);
            } else {
                Car car = new Car(input[0]);
                carList.add(car);
            }
        }
        for (Object o : carList) {
            System.out.println(o.toString());
        }

    }
}
